﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;


namespace WebServiceSOAP
{
    [ServiceContract]
    public interface IBMICalculatorService
    {
        [OperationContract]
        double myBMI(int height, int weight);

        [OperationContract]
        BMIResult myHealth(int height, int weight);
    }

    // Sata structure of the result returned by myHealth method
    public class BMIResult
    {
        public double Bmi { get; set; }
        public string Risk { get; set; }
        public string[] More { get; set; }
    }
}
