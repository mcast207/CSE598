﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using BMICalculatorProjectSOAP;

namespace BMICalculatorProjectSOAP
{
  
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    public class BMICalculatorServiceSOAP : System.Web.Services.WebService
    {

        [WebMethod]
        public double myBMI(int height, int weight)
        {
            return Math.Round((weight / (double)(height * height)) * 703, 2);
        }

        [WebMethod]
        public BMIResult myHealth(int height, int weight)
        {
            double bmi = myBMI(height, weight);
            string risk;

            if (bmi < 18)
                risk = "You are underweight";
            else if (bmi >= 18 && bmi < 25)
                risk = "You are normal";
            else if (bmi >= 25 && bmi < 30)
                risk = "You are pre-obese";
            else
                risk = "You are obese";

            return new BMIResult
            {
                Bmi = bmi,
                Risk = risk,
                More = new string[]
                {
                    "https://www.cdc.gov/healthyweight/assessing/bmi/index.html",
                    "https://www.nhlbi.nih.gov/health/educational/lose_wt/index.htm",
                    "https://www.ucsfhealth.org/education/body_mass_index_tool/"
                }
            };
        }
    }
}
