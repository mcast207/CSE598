﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.UI;
using Newtonsoft.Json;

namespace BMICalculatorWebClient
{
    public partial class Default : Page
    {
      
      protected async void btnCalculateREST_Click(object sender, EventArgs e)
{
    try
    {
        double height = double.Parse(txtHeight.Text);
        double weight = double.Parse(txtWeight.Text);

        using (HttpClient client = new HttpClient())
        {
            // Call REST myBMI endpoint
            string bmiUrl = $"https://localhost:44380/api/bmi/myBMI?height={height}&weight={weight}";
            HttpResponseMessage bmiResponse = await client.GetAsync(bmiUrl);

            if (!bmiResponse.IsSuccessStatusCode)
            {
                lblBMI.Text = "Error retrieving BMI";
                return;
            }

            double bmi = double.Parse(await bmiResponse.Content.ReadAsStringAsync());

            // Call REST myHealth endpoint
            string healthUrl = $"https://localhost:44380/api/bmi/myHealth?height={height}&weight={weight}";
            HttpResponseMessage healthResponse = await client.GetAsync(healthUrl);

            if (!healthResponse.IsSuccessStatusCode)
            {
                lblRisk.Text = "Error retrieving health risk";
                return;
            }

            string healthJson = await healthResponse.Content.ReadAsStringAsync();
            var restResult = JsonConvert.DeserializeObject<BMIResult>(healthJson);

            // Determine the risk color to output based on requirements
            string color = restResult.Risk.Contains("underweight") ? "Blue" :
                           restResult.Risk.Contains("normal") ? "Green" :
                           restResult.Risk.Contains("pre-obese") ? "Purple" : "Red";

            // Output results with text and corresponding color
            lblServiceType.Text = "REST";
            lblBMI.Text = $"{bmi:F2}";
            lblRisk.Text = Server.HtmlDecode($"Health Risk: <span style='color:{color};'>{restResult.Risk}</span>");
            lblResources.Text = string.Join("<br />", restResult.More);
        }
    }
    catch (Exception ex)
    {
        // Handle exceptions 
        lblBMI.Text = "Error";
        lblBMI.Text = "N/A";
        lblRisk.Text = "N/A";
        lblRisk.Text = ex.Message;
    }
}

        protected async void btnCalculateSOAP_Click(object sender, EventArgs e)
        {
            try
            {
                string height = txtHeight.Text;
                string weight = txtWeight.Text;

                // Service reference to the SOAP service
                var client = new ServiceReferenceSOAP.BMICalculatorServiceClient();

                // Calling the SOAP method
                var response = await client.myHealthAsync(int.Parse(height), int.Parse(weight));

                // Determine the risk color to output based on requirements
                string color = response.Risk.Contains("underweight") ? "Blue" :
                               response.Risk.Contains("normal") ? "Green" :
                               response.Risk.Contains("pre-obese") ? "Purple" : "Red";

                // Output results with text and corresponding color
                lblServiceType.Text = "SOAP";
                lblBMI.Text = $"{response.Bmi:F2}";
                lblRisk.Text = Server.HtmlDecode($"Health Risk: <span style='color:{color};'>{response.Risk}</span>");
                lblResources.Text = string.Join("<br />", response.More);
            }
            catch (Exception ex)
            {
                // Handle exceptions 
                lblServiceType.Text = "Error";
                lblBMI.Text = "N/A";
                lblRisk.Text = "N/A";
                lblResources.Text = ex.Message;
            }
        }


        protected void btnReset_Click(object sender, EventArgs e)
        {
            // Clear the input fields and results
            txtHeight.Text = "";
            txtWeight.Text = "";
            lblBMI.Text = "--";
            lblRisk.Text = "--";
            lblResources.Text = "--";
            lblServiceType.Text = "--";
        }


        // The DisplayResults method
        private void DisplayResults(double bmi, string risk, string[] resources)
        {
            lblBMI.Text = $"{bmi:F2}";
            lblRisk.Text = risk;
            lblResources.Text = string.Join("<br />", resources);
        }

        public class BMIResult
        {
            public double Bmi { get; set; }
            public string Risk { get; set; }
            public string[] More { get; set; }
        }

        protected void txtHeight_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
