﻿using System;
using System.Web.Http;
using BMICalculatorProjectREST.Models;

namespace BMICalculatorREST.Controllers
{
    [RoutePrefix("api/bmi")]
    public class BMICalculatorRESTController : ApiController
    {
        [HttpGet]
        [Route("myBMI")]
        public double myBMI(int height, int weight)
        {
            // BMI calculation formula
            return Math.Round((weight / (double)(height * height)) * 703, 2);
        }

        [HttpGet]
        [Route("myHealth")]
        public BMIResult myHealth(int height, int weight)
        {
            double bmi = myBMI(height, weight);
            string risk;

            // Determine health risk based on BMI value
            if (bmi < 18)
                risk = "You are underweight";
            else if (bmi >= 18 && bmi < 25)
                risk = "You are normal";
            else if (bmi >= 25 && bmi < 30)
                risk = "You are pre-obese";
            else
                risk = "You are obese";

            return new BMIResult
            {
                Bmi = bmi,
                Risk = risk,
                More = new string[]
                {
                    "https://www.cdc.gov/healthyweight/assessing/bmi/index.html",
                    "https://www.nhlbi.nih.gov/health/educational/lose_wt/index.htm",
                    "https://www.ucsfhealth.org/education/body_mass_index_tool/"
                }
            };
        }
    }
}
