﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BMICalculatorProjectREST.Models
{
    public class BMIResult
    {
        public double Bmi { get; set; }
        public string Risk { get; set; }
        public string[] More { get; set; }
    }

}